﻿
namespace OSIO4
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.dialogView = new System.Windows.Forms.RichTextBox();
            this.loadButton = new System.Windows.Forms.Button();
            this.removeButton = new System.Windows.Forms.Button();
            this.backgroundWorkerDetector = new System.ComponentModel.BackgroundWorker();
            this.outputProcess = new System.Diagnostics.Process();
            this.secondInputProcess = new System.Diagnostics.Process();
            this.insertSpeedTextBox = new System.Windows.Forms.TextBox();
            this.saveButton = new System.Windows.Forms.Button();
            this.powShelProcess = new System.Diagnostics.Process();
            this.firstInputProcess = new System.Diagnostics.Process();
            this.PIDLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // notifyIcon
            // 
            this.notifyIcon.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.notifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_MouseDoubleClick);
            // 
            // dialogView
            // 
            this.dialogView.BackColor = System.Drawing.Color.Indigo;
            this.dialogView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dialogView.ForeColor = System.Drawing.SystemColors.ControlLight;
            resources.ApplyResources(this.dialogView, "dialogView");
            this.dialogView.Name = "dialogView";
            this.dialogView.ReadOnly = true;
            // 
            // loadButton
            // 
            this.loadButton.BackColor = System.Drawing.Color.Indigo;
            this.loadButton.ForeColor = System.Drawing.SystemColors.ControlLight;
            resources.ApplyResources(this.loadButton, "loadButton");
            this.loadButton.Name = "loadButton";
            this.loadButton.UseVisualStyleBackColor = false;
            this.loadButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // removeButton
            // 
            this.removeButton.BackColor = System.Drawing.Color.Indigo;
            this.removeButton.ForeColor = System.Drawing.SystemColors.ControlLight;
            resources.ApplyResources(this.removeButton, "removeButton");
            this.removeButton.Name = "removeButton";
            this.removeButton.UseVisualStyleBackColor = false;
            this.removeButton.Click += new System.EventHandler(this.disableButton_Click);
            // 
            // backgroundWorkerDetector
            // 
            this.backgroundWorkerDetector.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorkerDetector_DoWork);
            // 
            // outputProcess
            // 
            this.outputProcess.StartInfo.Domain = "";
            this.outputProcess.StartInfo.LoadUserProfile = false;
            this.outputProcess.StartInfo.Password = null;
            this.outputProcess.StartInfo.StandardErrorEncoding = null;
            this.outputProcess.StartInfo.StandardInputEncoding = null;
            this.outputProcess.StartInfo.StandardOutputEncoding = null;
            this.outputProcess.StartInfo.UserName = "";
            this.outputProcess.SynchronizingObject = this;
            this.outputProcess.OutputDataReceived += new System.Diagnostics.DataReceivedEventHandler(this.process1_OutputDataReceived);
            // 
            // secondInputProcess
            // 
            this.secondInputProcess.StartInfo.Domain = "";
            this.secondInputProcess.StartInfo.LoadUserProfile = false;
            this.secondInputProcess.StartInfo.Password = null;
            this.secondInputProcess.StartInfo.StandardErrorEncoding = null;
            this.secondInputProcess.StartInfo.StandardInputEncoding = null;
            this.secondInputProcess.StartInfo.StandardOutputEncoding = null;
            this.secondInputProcess.StartInfo.UserName = "";
            this.secondInputProcess.SynchronizingObject = this;
            this.secondInputProcess.OutputDataReceived += new System.Diagnostics.DataReceivedEventHandler(this.process1_OutputDataReceived);
            // 
            // insertSpeedTextBox
            // 
            this.insertSpeedTextBox.BackColor = System.Drawing.Color.Indigo;
            this.insertSpeedTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.insertSpeedTextBox.ForeColor = System.Drawing.SystemColors.ControlLight;
            resources.ApplyResources(this.insertSpeedTextBox, "insertSpeedTextBox");
            this.insertSpeedTextBox.Name = "insertSpeedTextBox";
            // 
            // saveButton
            // 
            this.saveButton.BackColor = System.Drawing.Color.Indigo;
            this.saveButton.ForeColor = System.Drawing.SystemColors.ControlLight;
            resources.ApplyResources(this.saveButton, "saveButton");
            this.saveButton.Name = "saveButton";
            this.saveButton.UseVisualStyleBackColor = false;
            this.saveButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // powShelProcess
            // 
            this.powShelProcess.StartInfo.Domain = "";
            this.powShelProcess.StartInfo.LoadUserProfile = false;
            this.powShelProcess.StartInfo.Password = null;
            this.powShelProcess.StartInfo.StandardErrorEncoding = null;
            this.powShelProcess.StartInfo.StandardInputEncoding = null;
            this.powShelProcess.StartInfo.StandardOutputEncoding = null;
            this.powShelProcess.StartInfo.UserName = "";
            this.powShelProcess.SynchronizingObject = this;
            // 
            // firstInputProcess
            // 
            this.firstInputProcess.StartInfo.Domain = "";
            this.firstInputProcess.StartInfo.LoadUserProfile = false;
            this.firstInputProcess.StartInfo.Password = null;
            this.firstInputProcess.StartInfo.StandardErrorEncoding = null;
            this.firstInputProcess.StartInfo.StandardInputEncoding = null;
            this.firstInputProcess.StartInfo.StandardOutputEncoding = null;
            this.firstInputProcess.StartInfo.UserName = "";
            this.firstInputProcess.SynchronizingObject = this;
            this.firstInputProcess.OutputDataReceived += new System.Diagnostics.DataReceivedEventHandler(this.process2_OutputDataReceived);
            // 
            // PIDLabel
            // 
            resources.ApplyResources(this.PIDLabel, "PIDLabel");
            this.PIDLabel.Name = "PIDLabel";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Indigo;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Name = "label2";
            // 
            // MainForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::OSIO4.Properties.Resources.wallhaven_72pe8v;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.insertSpeedTextBox);
            this.Controls.Add(this.PIDLabel);
            this.Controls.Add(this.removeButton);
            this.Controls.Add(this.loadButton);
            this.Controls.Add(this.dialogView);
            this.Name = "MainForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.RichTextBox dialogView;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.ComponentModel.BackgroundWorker backgroundWorkerDetector;
        private System.Diagnostics.Process outputProcess;
        private System.Diagnostics.Process secondInputProcess;
        private System.Windows.Forms.TextBox insertSpeedTextBox;
        private System.Windows.Forms.Button saveButton;
        private System.Diagnostics.Process powShelProcess;
        private System.Diagnostics.Process firstInputProcess;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label PIDLabel;
    }
}

