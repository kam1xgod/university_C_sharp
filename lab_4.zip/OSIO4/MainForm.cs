﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Management;
using System.IO;
using System.Threading;
using System.Text;
using System.IO.Pipes;

namespace OSIO4
{
    public partial class MainForm : Form
    {
        static NamedPipeClientStream client1;
        static NamedPipeClientStream client2;
        public StreamWriter writer1;
        public StreamWriter writer2;
        public MainForm()
        {
            bool isStarted = true;
            InitializeComponent();
            notifyIcon.Icon = new System.Drawing.Icon(@"D:\_Progi (c#) 4 sem\lab_4\icon.ico");
            backgroundWorkerDetector.RunWorkerAsync();

            client1 = new NamedPipeClientStream(".", "Input1", PipeDirection.Out);
            firstInputProcess.StartInfo.CreateNoWindow = false;
            firstInputProcess.StartInfo.FileName = @"D:\_Progi (c#) 4 sem\lab_4\INP\bin\Debug\net5.0\Input1.exe";
            firstInputProcess.StartInfo.Verb = "runas";
            firstInputProcess.StartInfo.UseShellExecute = false;
            firstInputProcess.Start();

            client2 = new NamedPipeClientStream(".", "Input2", PipeDirection.Out);
            secondInputProcess.StartInfo.CreateNoWindow = false;
            secondInputProcess.StartInfo.FileName = @"D:\_Progi (c#) 4 sem\lab_4\Input2\bin\Debug\net5.0\Input2.exe";
            secondInputProcess.StartInfo.Verb = "runas";
            secondInputProcess.StartInfo.UseShellExecute = false;
            secondInputProcess.Start();

            powShelProcess.StartInfo.UseShellExecute = false;
            powShelProcess.StartInfo.Verb = "runas";
            powShelProcess.StartInfo.RedirectStandardInput = true;
            powShelProcess.StartInfo.CreateNoWindow = false;
            powShelProcess.StartInfo.FileName = @"C:\windows\system32\windowspowershell\v1.0\powershell.exe";

            outputProcess.StartInfo.CreateNoWindow = false;
            outputProcess.StartInfo.StandardOutputEncoding = Encoding.UTF8;
            outputProcess.StartInfo.RedirectStandardOutput = true;
            outputProcess.EnableRaisingEvents = true;
            outputProcess.StartInfo.RedirectStandardInput = true;
            outputProcess.StartInfo.UseShellExecute = false;
            outputProcess.StartInfo.FileName = @"D:\_Progi (c#) 4 sem\lab_4\out\bin\Debug\net5.0\outt.exe";

            client1.Connect();
            client1.ReadMode = PipeTransmissionMode.Message;
            client2.Connect();
            client2.ReadMode = PipeTransmissionMode.Message;
            writer1 = new StreamWriter(client1);
            writer1.AutoFlush = true;
            writer2 = new StreamWriter(client2);
            writer2.AutoFlush = true;

            ThreadPool.QueueUserWorkItem((WaitCallback)(o => {
                while(isStarted)
                {
                    string id = "";
                    var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption = 'VGA WebCam'");
                    foreach (var device in searcher.Get())
                    {
                        id = device["deviceid"].ToString();
                    }
                    writer2.WriteLine(@"D:\_Progi (c#) 4 sem\lab_4\log2.txt" + "~" + id);
                    writer2.WriteLine("Complete");
                    client2.WaitForPipeDrain();

                    writer1.WriteLine(@"D:\_Progi (c#) 4 sem\lab_4\log1.txt" + "~" + id);
                    writer1.WriteLine("Complete");
                    client1.WaitForPipeDrain();
                }
            }));
            ThreadPool.QueueUserWorkItem((WaitCallback)(o =>
            {
                while (isStarted)
                {
                    outputProcess.Start();
                    outputProcess.StandardInput.WriteLine(@"D:\_Progi (c#) 4 sem\lab_4\log1.txt");
                    outputProcess.StandardInput.WriteLine(insertSpeedTextBox.Text);
                    dialogView.BeginInvoke(new Action(() =>
                    {
                        dialogView.Clear();
                    }));
                    outputProcess.Start();
                    outputProcess.StandardInput.WriteLine(@"D:\_Progi (c#) 4 sem\lab_4\log2.txt");
                    outputProcess.StandardInput.WriteLine(insertSpeedTextBox.Text);
                    dialogView.BeginInvoke(new Action(() =>
                    {
                        dialogView.Clear();
                    }));
                    outputProcess.BeginOutputReadLine();
                    outputProcess.WaitForExit();
                    outputProcess.CancelOutputRead();
                }
            }));
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            ThreadPool.QueueUserWorkItem((WaitCallback)(o =>
            {
                outputProcess.Start();
                outputProcess.StandardInput.WriteLine(@"D:\_Progi (c#) 4 sem\lab_4\Save.txt");
                outputProcess.StandardInput.WriteLine(insertSpeedTextBox.Text);
                this.dialogView.BeginInvoke(new Action(() =>
                {
                    this.dialogView.Clear();
                }));
                outputProcess.BeginOutputReadLine();
                outputProcess.WaitForExit();
                outputProcess.CancelOutputRead();
            }));
        }
        private void saveButton_Click(object sender, EventArgs e)
        {
            string id = PIDLabel.Text;
            writer1.WriteLine(@"D:\_Progi (c#) 4 sem\lab_4\Save.txt" + "~" + id);
            writer1.WriteLine("Complete");
            client1.WaitForPipeDrain();
        }


        private void disableButton_Click(object sender, EventArgs e)
        {
            string id = PIDLabel.Text;

            powShelProcess.Start();
            powShelProcess.StandardInput.WriteLine(@"Disable-PnpDevice -InstanceId " + "'" + id + "'" + " -confirm:$false");
            powShelProcess.StandardInput.WriteLine("Exit");
        }

        private void process1_OutputDataReceived(object sender, System.Diagnostics.DataReceivedEventArgs e)
        {
            if (!String.IsNullOrEmpty(e.Data))
                {
                dialogView.BeginInvoke(new Action(() =>
                {
                    if(e.Data.StartsWith("<>"))
                    {
                        dialogView.AppendText("\n");
                    }
                    else if(e.Data.StartsWith("`"))
                    {
                        dialogView.AppendText(" ");
                    }
                    else
                    {
                        dialogView.AppendText(e.Data);
                    }
                }));
            }
        }
        private void process2_OutputDataReceived(object sender, System.Diagnostics.DataReceivedEventArgs e)
        {
            Console.WriteLine(e.Data);
            if (!String.IsNullOrEmpty(e.Data))
            {
                dialogView.BeginInvoke(new Action(() =>
                {
                    
                    if (e.Data.StartsWith("<>"))
                    {
                        dialogView.AppendText("\n");
                    }
                    else if (e.Data.StartsWith("`"))
                    {
                        dialogView.AppendText(" ");
                    }
                    else
                    {
                        dialogView.AppendText(e.Data);
                    }
                }));
            }
        }
        private void DeviceInsertedEvent(object sender, EventArrivedEventArgs e)
        {
            ManagementBaseObject instance = (ManagementBaseObject)e.NewEvent["TargetInstance"];
            notifyIcon.ShowBalloonTip(1000, "Device connected", instance["Caption"] + "\n Device ID:" + instance["deviceid"], ToolTipIcon.Info);
            PIDLabel.BeginInvoke(new Action(() =>
            {
                PIDLabel.Text = instance["deviceid"].ToString();
            }));
        }
        
        private void DeviceRemovedEvent(object sender, EventArrivedEventArgs e)
        {
            ManagementBaseObject instance = (ManagementBaseObject)e.NewEvent["TargetInstance"];
            notifyIcon.ShowBalloonTip(1000, "Device disconected", instance["Caption"] + "\n Device ID:" + instance["deviceid"], ToolTipIcon.Info);
            PIDLabel.BeginInvoke(new Action(() =>
            {
                PIDLabel.Text.Replace(instance["deviceid"].ToString(), "", StringComparison.OrdinalIgnoreCase);
            }));
            
        }

        private void backgroundWorkerDetector_DoWork(object sender, DoWorkEventArgs e)
        {
            WqlEventQuery insertQuery = new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_USBHub'");

            ManagementEventWatcher insertWatcher = new ManagementEventWatcher(insertQuery);
            insertWatcher.EventArrived += new EventArrivedEventHandler(DeviceInsertedEvent);
            insertWatcher.Start();

            WqlEventQuery removeQuery = new WqlEventQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 3 WHERE TargetInstance ISA 'Win32_USBHub'");
            ManagementEventWatcher removeWatcher = new ManagementEventWatcher(removeQuery);
            removeWatcher.EventArrived += new EventArrivedEventHandler(DeviceRemovedEvent);
            removeWatcher.Start();
        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                Hide();
                notifyIcon.Visible = true;
            }
        }
        private void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
            notifyIcon.Visible = false;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                firstInputProcess.Kill();
                secondInputProcess.Kill();
                outputProcess.Kill();
            }
            catch (ObjectDisposedException exc)
            {

            }
        }
    }

}
