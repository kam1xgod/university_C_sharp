﻿using System;
using System.IO;
using System.IO.Pipes;
using System.Management;

namespace INP
{
    class Program
    {
        public static NamedPipeServerStream server;
        static StreamReader sr;
        static void Main(string[] args)
        {
            server = new NamedPipeServerStream("Input1", PipeDirection.In, 10, PipeTransmissionMode.Message, PipeOptions.WriteThrough, 2048, 2048);

            server.WaitForConnection();
            sr = new StreamReader(server);
            while (true)
            {
                string tmp;
                if ((tmp = sr.ReadLine()) != null)
                {
                    Console.WriteLine(tmp);
                    string path = "";
                    string id = "";
                    try
                    {
                        path = tmp.Split("~")[0];
                        id = tmp.Split("~")[1];
                    }
                    catch (IndexOutOfRangeException exc)
                    {

                    }
                    using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption = 'VGA WebCam'"))
                    {
                        Console.WriteLine(searcher.Get().Count);
                        Console.WriteLine(id);
                        foreach (var device in searcher.Get())
                        {
                            Console.WriteLine(device["deviceid"].ToString());
                            if(device["deviceid"].ToString().StartsWith(id))
                            {
                                using (StreamWriter writer = new StreamWriter(path, false)) //// true to append data to the file
                                {
                                    bool isDateWrited = false;
                                    foreach (var property in device.Properties)
                                    {
                                        if (!isDateWrited)
                                        {
                                            isDateWrited = true;
                                            writer.WriteLine(DateTime.Now);
                                        }
                                        writer.WriteLine(property.Name + " = " + property.Value);
                                    }
                                }
                            }
                        }
                    }
                    sr.ReadLine();
                }
            }


        }
    }
}

